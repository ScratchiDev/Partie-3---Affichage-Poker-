import java.util.*;

public class MainPoker implements Comparable<MainPoker> {
    private String[] cartes;
    private static final Map<Character, Integer> VALEURS;
    private static final char[] VALEURS_CARTES = {'2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'};
    private static final String[] SYMBOLES_COULEUR = {"♠", "♥", "♦", "♣"};
    private static final char[] UNICODES_COULEUR = {'\u2660', '\u2665', '\u2666', '\u2663'};

    static {
        Map<Character, Integer> valeurs = new HashMap<>();
        valeurs.put('2', 2);
        valeurs.put('3', 3);
        valeurs.put('4', 4);
        valeurs.put('5', 5);
        valeurs.put('6', 6);
        valeurs.put('7', 7);
        valeurs.put('8', 8);
        valeurs.put('9', 9);
        valeurs.put('T', 10);
        valeurs.put('J', 11);
        valeurs.put('Q', 12);
        valeurs.put('K', 13);
        valeurs.put('A', 14);
        VALEURS = Collections.unmodifiableMap(valeurs);
    }

    public MainPoker(String[] main) {
        this.cartes = main;
        Arrays.sort(this.cartes, Comparator.comparingInt(carte -> VALEURS.get(carte.charAt(0))));
    }

    @Override
    public int compareTo(MainPoker autre) {
        int rangCetteMain = evaluerRang(this.cartes);
        int rangAutreMain = evaluerRang(autre.cartes);
        return Integer.compare(rangCetteMain, rangAutreMain);
    }

    private int evaluerRang(String[] cartes) {
        return VALEURS.get(cartes[4].charAt(0));
    }

    public static MainPoker genererMainAleatoire() {
        List<String> jeu = new ArrayList<>();
        for (char valeur : VALEURS_CARTES) {
            for (String symbole : SYMBOLES_COULEUR) {
                jeu.add("" + valeur + symbole);
            }
        }
        Collections.shuffle(jeu);
        String[] main = new String[5];
        for (int i = 0; i < 5; i++) {
            main[i] = jeu.get(i);
        }
        return new MainPoker(main);
    }

    public Result comparerAvec(MainPoker autre) {
        int rangCetteMain = evaluerRang(this.cartes);
        int rangAutreMain = evaluerRang(autre.cartes);
        if (rangCetteMain > rangAutreMain) {
            return Result.GAGNE;
        } else if (rangCetteMain < rangAutreMain) {
            return Result.PERDU;
        } else {
            return comparerValeursCartes(this.cartes, autre.cartes);
        }
    }

    private Result comparerValeursCartes(String[] main1, String[] main2) {
        for (int i = 4; i >= 0; i--) {
            int valeurCarteMain1 = VALEURS.get(main1[i].charAt(0));
            int valeurCarteMain2 = VALEURS.get(main2[i].charAt(0));
            if (valeurCarteMain1 > valeurCarteMain2) {
                return Result.GAGNE;
            } else if (valeurCarteMain1 < valeurCarteMain2) {
                return Result.PERDU;
            }
        }
        return Result.EGALITE;
    }

    public String toString() {
        StringBuilder constructeur = new StringBuilder();
        for (String carte : cartes) {
            constructeur.append(carte).append(" ");
        }
        return constructeur.toString();
    }

    public void afficherAsciiArt() {
        String[][] asciiCartes = new String[VALEURS_CARTES.length * SYMBOLES_COULEUR.length][7];

        for (int i = 0; i < VALEURS_CARTES.length; i++) {
            for (int j = 0; j < SYMBOLES_COULEUR.length; j++) {
                asciiCartes[i * SYMBOLES_COULEUR.length + j][0] = "┌───────────┐";
                asciiCartes[i * SYMBOLES_COULEUR.length + j][1] = "│ " + VALEURS_CARTES[i] + "         │";
                asciiCartes[i * SYMBOLES_COULEUR.length + j][2] = "│           │";
                asciiCartes[i * SYMBOLES_COULEUR.length + j][3] = "│     " + SYMBOLES_COULEUR[j] + "     │";
                asciiCartes[i * SYMBOLES_COULEUR.length + j][4] = "│           │";
                asciiCartes[i * SYMBOLES_COULEUR.length + j][5] = "│         " + VALEURS_CARTES[i] + " │";
                asciiCartes[i * SYMBOLES_COULEUR.length + j][6] = "└───────────┘";
            }
        }

        for (int i = 0; i < 7; i++) {
            for (String carte : cartes) {
                int indexValeurCarte = getIndexValeurCarte(carte.charAt(0));
                int indexCouleurCarte = getIndexCouleurCarte(carte.charAt(1));
                System.out.print(asciiCartes[indexValeurCarte * SYMBOLES_COULEUR.length + indexCouleurCarte][i]);
            }
            System.out.println();
        }
    }


    private int getIndexValeurCarte(char valeur) {
        for (int i = 0; i < VALEURS_CARTES.length; i++) {
            if (VALEURS_CARTES[i] == valeur) {
                return i;
            }
        }
        return -1;
    }

    private int getIndexCouleurCarte(char couleur) {
        String couleurStr = String.valueOf(couleur);
        for (int i = 0; i < SYMBOLES_COULEUR.length; i++) {
            if (SYMBOLES_COULEUR[i].equals(couleurStr)) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        try {
            MainPoker main1 = genererMainAleatoire();
            MainPoker main2 = genererMainAleatoire();

            Result resultat = main1.comparerAvec(main2);
            System.out.println("Résultat: " + resultat);

            ArrayList<MainPoker> mains = new ArrayList<>();
            mains.add(main1);
            mains.add(main2);

            Collections.sort(mains);

            System.out.println("Mains triées : ");
            for (MainPoker main : mains) {
                System.out.println(main.toString());
                main.afficherAsciiArt();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

enum Result {
    GAGNE,
    PERDU,
    EGALITE
}
